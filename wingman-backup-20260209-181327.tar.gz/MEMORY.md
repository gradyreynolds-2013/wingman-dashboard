# MEMORY.md - Wingman's Long-Term Memory

## Core Infrastructure

### Wingman Activity Dashboard
- **Live at:** http://18.118.31.236:8080
- **Purpose:** Real-time activity tracking, task management, quick access to tools
- **Status:** ✅ Built and operational (HTML/CSS/JS self-hosted)
- **Issue:** Crashes intermittently; keep-alive script created but needs systemd deployment
- **Components:** Tasks, links, well files inventory, activity timeline, project status
- **Future Plan:** Migrate to Netlify (eliminates server crashes, reliability)
- **Files Location:** `/home/ubuntu/clawd/wingman-dashboard/`
  - `index.html` - UI
  - `activity.json` - Activity data (auto-updated)
  - `tasks.json` - Quick tasks list (auto-updated, ordered by due date)
  - `wells.json` - Rig file inventory (36 documents across 5 wells)
  - `start-server.sh` - Keep-alive script (not yet deployed to systemd)

### Google Workspace Integration
- **Service Account Email:** wingman-bot-service-account@wingman-bot.iam.gserviceaccount.com
- **Service Account ID:** 107568506848093825308
- **Credentials Path:** `/home/ubuntu/.config/wingman-service-account.json`
- **Google Cloud Project:** wingman-bot (GCP)
- **APIs Enabled:** Drive, Sheets, Calendar, Docs
- **Folder Access:** Wingman folder (ID: 1YYLYqXMlRuD3_iOPMUybM5lAenD2i4fH)
- **Folder Organization:**
  - OZ Fund/ (pro formas, guides, investor scripts)
  - Marketing/ (content calendar, social media)
  - Sales Tools/ (investor pitches, objection scripts)
  - Resources/ (NEPQ PDFs, reference materials)
  - System/ (backups, archives, well files)
- **Status:** ✅ Service account created; ⏳ Awaiting Wingman folder share (Editor access)
- **Capabilities:**
  - ✅ Read/write Google Drive files (once folder shared)
  - ✅ Create/update Google Sheets
  - ✅ Read/update Google Docs
  - ✅ Pull calendar events
  - ⚠️ Create NEW files (quota exceeded; workaround: user creates, I update)
- **gog CLI Status:** Not yet configured with service account
- **Security:** No personal login; pure service account access

### Google Drive Organization
**Wingman folder structure:**
```
Wingman/
├── OZ Fund/ (pro formas, guides, investor scripts)
├── Marketing/ (content calendar, social media)
├── Sales Tools/ (investor pitches, objection scripts)
├── Resources/ (NEPQ PDFs, reference materials)
└── System/ (backups, archives)
```
**Total:** 36 files, 5 organized folders, all content preserved

### AI Models Available
- **Anthropic:** Sonnet 4.5 (primary), Opus 4.5 (heavy thinking), Haiku 4.5 (lightweight)
- **Google:** Gemini 3 Flash Preview
- **xAI:** Grok 4.1 (fast reasoning)
- **OpenAI:** GPT-4o, DALL-E 3 (image generation)
- **Image Generation:** DALLE-3 working (API key configured)

### Rig Well Documents
**All 36 documents indexed and tracked:**
- 204H: 7 documents
- 205H: 7 documents
- 504H: 8 documents
- 801H: 9 documents
- 901H: 6 documents

## Grady's Current Priorities

### Current Status: Off Hitch (since 2026-02-03)

**Dashboard Priorities (Feb 8-12):**
- ✅ Build Wingman Activity Dashboard (DONE)
- ⏳ Deploy keep-alive script to systemd for persistence (BLOCKED on testing)
- 🎯 Set up service account Google Drive/Calendar access (BLOCKED on folder share)
- 🎯 Enable autonomous task management (BLOCKED on service account setup)

**Business Focus (Feb 15+):**
- Set up CREXI automation (due Feb 10)
- Research first OZ property target (apartments in Opportunity Zones)
- Finalize OZ fund website (positioning + copy + deployment)
- Create investor outreach list (LP identification)

**Business Model:** Vertically integrated real estate company in Opportunity Zones (QOZ strategy)

## Key Decisions & Setup

### Architecture Choices
- **Service Account Access:** wingman-bot-service-account (direct, no user interaction required)
- **Dashboard Hosting:** Self-hosted on EC2 (user preference; fragility risk mitigated by keep-alive script)
- **Google File Creation:** Limited by quota; pattern = user creates file, Wingman updates content
- **Task Management:** JSON-based quick tasks (auto-synced to dashboard, ordered by due date)
- **Well Files:** Centralized in System folder for drilling consultant work
- **Model Strategy:** Haiku for lightweight automation (cost efficiency)

### Current Blockers
1. **Service Account Folder Access:** Awaiting Grady to share Wingman folder with service account (Editor access)
2. **Dashboard Persistence:** Keep-alive script created but not yet deployed to systemd
3. **gog CLI Configuration:** Need to configure with service account credentials

## Next Architecture Steps (Ordered by Dependency)

**Phase 1: Unblock Google Access**
1. Share Wingman folder with service account (Editor access) ← **BLOCKER**
2. Configure gog CLI with service account credentials
3. Test Drive/Sheets/Calendar access via `gog` commands

**Phase 2: Dashboard Resilience**
4. Deploy keep-alive script to systemd for persistence
5. Add health checks and auto-restart logic

**Phase 3: Automation & Intelligence**
6. Enable autonomous Quick Tasks management (read/write to tasks.json)
7. Implement CREXI automation (due Feb 10)
8. Build "Today's Focus" dashboard section (AI-generated daily briefing)
9. Calendar Sync - Pull hitch dates, deadline tracking
10. Investor Tracking Sheet - LP pipeline management

---

**Last Updated:** 2026-02-08 (Session: Pre-Compaction Flush - Service Account Setup, Dashboard Build Complete)
